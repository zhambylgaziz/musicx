-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Апр 17 2018 г., 06:44
-- Версия сервера: 10.1.21-MariaDB
-- Версия PHP: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `music`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf32_bin NOT NULL,
  `time` date NOT NULL,
  `comment` varchar(255) COLLATE utf32_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Дамп данных таблицы `comment`
--

INSERT INTO `comment` (`id`, `name`, `time`, `comment`) VALUES
(1, 'John', '2018-04-09', 'Nice! Good job! Well done!'),
(2, 'Sam', '2018-04-08', 'Good. Can listen. Slider is awesome!');

-- --------------------------------------------------------

--
-- Структура таблицы `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf32_bin NOT NULL,
  `passwd` varchar(255) COLLATE utf32_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Дамп данных таблицы `login`
--

INSERT INTO `login` (`id`, `username`, `passwd`) VALUES
(4, 'qwe', '76d80224611fc919a5d54f0ff9fba446'),
(5, 'admin', '200820e3227815ed1756a6b531e7e0d2'),
(6, 'zdarovabandity', 'f5bb0c8de146c67b44babbf4e6584cc0'),
(7, 'asd', '7815696ecbf1c96e6894b779456d330e');

-- --------------------------------------------------------

--
-- Структура таблицы `reg`
--

CREATE TABLE `reg` (
  `uid` int(11) NOT NULL,
  `firstname` varchar(255) COLLATE utf32_bin NOT NULL,
  `lastname` varchar(255) COLLATE utf32_bin NOT NULL,
  `email` varchar(255) COLLATE utf32_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Дамп данных таблицы `reg`
--

INSERT INTO `reg` (`uid`, `firstname`, `lastname`, `email`) VALUES
(4, 'qwe', 'qwe', 'qwe@f.o'),
(5, 'admin', 'admin', 'admin@music.info'),
(6, 'salam', 'pacanam', 'salam@gmail.com'),
(7, 'asd', 'asd', 'asd@g.c');

-- --------------------------------------------------------

--
-- Структура таблицы `uploads`
--

CREATE TABLE `uploads` (
  `sid` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf32_bin NOT NULL,
  `title` varchar(255) COLLATE utf32_bin NOT NULL,
  `img` varchar(255) COLLATE utf32_bin NOT NULL,
  `audio` varchar(255) COLLATE utf32_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_bin;

--
-- Дамп данных таблицы `uploads`
--

INSERT INTO `uploads` (`sid`, `name`, `title`, `img`, `audio`) VALUES
(1, 'Khalid', 'American Dream', 'american.jpg', 'Khalid - Young Dumb  Broke.mp3'),
(2, 'Ed Sheeran', 'Divide', 'divide.jpg', 'Ed Sheeran - Galway Girl.mp3'),
(3, 'G-Eazy', 'Beautiful and Damned', 'beautiful.png', 'G-Eazy feat. A$AP Rocky  Cardi B - No Limit.mp3'),
(7, 'M0', 'When I was young', 'when.jpg', 'M0 - When I Was Young.mp3'),
(10, 'Bebe Rexha', 'All your fault', 'allyour.jpg', 'Bebe Rexha - F.F.F. (feat. G-Eazy).mp3');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `reg`
--
ALTER TABLE `reg`
  ADD PRIMARY KEY (`uid`);

--
-- Индексы таблицы `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `reg`
--
ALTER TABLE `reg`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `uploads`
--
ALTER TABLE `uploads`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
